from flask import Flask, request, redirect, render_template, session, g, url_for, send_file, make_response,jsonify, flash, send_from_directory
import pandas as pd
import datetime
import json
import pyodbc
import hashlib
from datetime import datetime
from email.mime.multipart import MIMEMultipart
import smtplib
from email.mime.text import MIMEText
################
######### comment added here##############

app = Flask(__name__)
app.secret_key = "pavanrashmi"
cnxn_str = ("Driver={ODBC Driver 17 for SQL Server};"
            "Server=dkrdsvdcp11\dpa;"
            "Database=VPDC;"
            "Trusted_Connection=yes;")

def send_email(email_recipient, email_subject, email_message,mail_df):
    email_sender = 'roc@scipher.io'
    sender_password='M(213213313787oq2025'
    # Convert df to HTML table
    html_table = mail_df.to_html(index=False, border=1)

    # Combine the plain text message and HTML table
    html_message = f"""
    <html>
        <body>
            <p>{email_message.replace('/n', '<br>')}</p>
            {html_table}
            <br>
            <p>Regards,<br>System@Event Classification VDC</p>
        </body>
    </html>
    """

    msg = MIMEMultipart("alternative")
    msg['From'] = email_sender
    msg['To'] = email_recipient
    msg['Subject'] = email_subject

    msg.attach(MIMEText(html_message, 'html'))

    try:
        server = smtplib.SMTP('smtp.office365.com', 587)
        server.starttls()
        server.login(email_sender, sender_password)
        server.sendmail(email_sender, email_recipient, msg.as_string())
        print("Email sent successfully.")
        server.quit()
    except Exception as e:
        print(f"SMTP server connection error: {e}")
        return True
   

@app.route('/user-management', methods=['GET', 'POST'])
def usermanagement():
    if 'user_name' in session:
        try:
            cnxn = pyodbc.connect(cnxn_str)
            cursor = cnxn.cursor()
            cursor.execute("SELECT DISTINCT username, type,  id FROM rocc.users ORDER BY username DESC;")
            users = cursor.fetchall()
            cursor.close()
            cnxn.close()

            return render_template("user_management.html", users=users)
        except Exception as e:
            print("Error fetching users:", e)
            return render_template('user_management.html', users=[], error="Error loading users")
    else:
        return render_template('login.html', info="Please login to continue")


@app.route('/new', methods=['GET', 'POST'])
def new():
    if 'user_name' in session:
        if request.method == "POST":
            usernam = request.form.get('email')
            pas = request.form.get('password')
            retype = request.form.get('retype')
            typ = request.form.get('inlineRadioOptions')
            print(typ)

            try:
                cnxn = pyodbc.connect(cnxn_str)
                cursor = cnxn.cursor()

                cursor.execute("SELECT MAX(CAST(SUBSTRING(id, CHARINDEX('_', id) + 1, LEN(id)) AS INT)) FROM rocc.users")
                max_id = cursor.fetchone()[0] or 0
                new_id = f"u_{int(max_id) + 1}"

                if pas == retype:
                    hashed_password = hashlib.sha256(pas.encode()).hexdigest().upper()
                    cursor.execute("""
                        INSERT INTO rocc.users( username, password, type)
                        VALUES ( ?, ?, ?)""", ( usernam, hashed_password, typ))
                    cnxn.commit()

                    cursor.execute("SELECT username, type FROM rocc.users ORDER BY username DESC")
                    users = cursor.fetchall()
                    return render_template("user_management.html", users=users)

                else:
                    error = "Passwords do not match"
                    cursor.execute("SELECT username, type FROM rocc.users ORDER BY username DESC")
                    users = cursor.fetchall()
                    return render_template("user_management.html", users=users, error=error, usernam=usernam)
            except Exception as e:
                return f"Error: {e}"
        else:
            return "GET request not allowed here."
    else:
        return render_template('login.html', info="Please login to continue")
    
@app.route('/edit', methods=['GET', 'POST'])
def edit():
    if 'user_name' in session:
        try:
            user_id = request.form.get('inlineRadioOptions')  # ID of the selected user
            print("Editing User ID:", str(user_id))

            cnxn = pyodbc.connect(cnxn_str)
            cursor = cnxn.cursor()

            cursor.execute("SELECT username, type, id FROM rocc.users WHERE id = ?", (user_id,))
            chosen = cursor.fetchall()

            cursor.execute("SELECT username, type, id FROM rocc.users ORDER BY username DESC")
            users = cursor.fetchall()

            return render_template("edit.html", users=users, chosen=chosen)

        except Exception as e:
            return f"Error in edit route: {e}"

    else:
        return render_template('login.html', info="Please login to continue")


@app.route('/edits', methods=['POST'])
def edits():
    if 'user_name' in session:
        email = request.form.get('email')
        typ = request.form.get('a')
        user_id = request.form.get('id')

        try:
            cnxn = pyodbc.connect(cnxn_str)
            cursor = cnxn.cursor()
            cursor.execute("""
                UPDATE rocc.users
                SET username = ?, type = ?
                WHERE id = ?
            """, (email, typ, user_id))
            cnxn.commit()

            cursor.execute("SELECT username, type, id FROM rocc.users ORDER BY username ASC")
            users = cursor.fetchall()
            return render_template("user_management.html", users=users)

        except Exception as e:
            return f"Error: {e}"
    else:
        return render_template('login.html', info="Please login to continue")

    
@app.route('/de', methods=['POST'])
def de():
    if 'user_name' in session:
        delete_ids = request.form.getlist('d')
        try:
            cnxn = pyodbc.connect(cnxn_str)
            cursor = cnxn.cursor()
            for user_id in delete_ids:
                cursor.execute("DELETE FROM rocc.users WHERE id = ?", (user_id,))
            cnxn.commit()

            cursor.execute("SELECT username, type, id FROM rocc.users ORDER BY username DESC")
            users = cursor.fetchall()
            return render_template("user_management.html", users=users)
        except Exception as e:
            return f"Error: {e}"
    else:
        return render_template('login.html', info="Please login to continue")


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest().upper()




def fetch_turbine_data():
    try:
        connection = pyodbc.connect(cnxn_str)
        cursor = connection.cursor()
        
        # Correct SQL query
        turbineeventquery = "SELECT dturbineeventid,Logno,Description,ControllerName,EngineeringSystemName,EngineeringSystem FROM dim.turbineevent"
        cursor.execute(turbineeventquery)
        
        rows = cursor.fetchall()
        columns = [column[0] for column in cursor.description]
        turbineevent_df = pd.DataFrame.from_records(rows, columns=columns)

        logquery = "SELECT * FROM rocc.LogNoSystemClassification"
        cursor.execute(logquery)

        rows = cursor.fetchall()
        columns = [column[0] for column in cursor.description]
        log_df = pd.DataFrame.from_records(rows, columns=columns)
        print(log_df.columns)

        cursor.close()
        connection.close()
       
        return turbineevent_df, log_df  

    except Exception as e:
        print("Error:", e)
        return pd.DataFrame(), pd.DataFrame()  # Return empty DataFrames on error


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':     
            user_name = request.form.get('username')
            pass_word = request.form.get('password')
            hashed_pw = hash_password(pass_word)
            print(user_name,'--->', pass_word,'---->', hashed_pw)
            try:
                with pyodbc.connect(cnxn_str) as conn:
                    cursor = conn.cursor()
                    cursor.execute("""
                        SELECT id, type FROM rocc.users 
                        WHERE username = ? AND password = ?
                    """, (user_name, hashed_pw))
                    user = cursor.fetchone()
                if user:
                        session['user_name']=user_name
                        cursor.execute("SELECT type FROM rocc.users WHERE username = ?", (user_name,))
                        result = cursor.fetchone()
                        if result:
                            session['type'] = result[0]
                            resp = redirect(url_for('home'))
                            resp.set_cookie('in', user_name)  
                            return resp
                else:
                    return render_template('login.html', info='Invalid username or password!')
            except Exception as e:
                print("Error:", e)
    return render_template('login.html')


@app.route('/home')
def home():
    if 'user_name' not in session:
        return redirect(url_for('index'))  

    turbineevent_df, log_df = fetch_turbine_data()

    # Extract unique Controller Names safely
    ctrlnames = sorted(set(turbineevent_df.get("ControllerName", [])).union(
                        set(log_df.get("Controllername", []))))

    return render_template('home_new.html', ctrlnames=ctrlnames, user=session['user_name'], type=session['type'])

@app.route('/get_engsystem', methods=['POST'])
def get_engsystem():
    turbineevent_df, log_df = fetch_turbine_data()
    selected_ctrlname = request.json.get('ctrlname', '')
    print("selected ctrl name ",selected_ctrlname)

    filtered_eng_systems = sorted(set(turbineevent_df[turbineevent_df["ControllerName"] == selected_ctrlname]["EngineeringSystem"])
                                  .union(set(log_df[log_df["Controllername"] == selected_ctrlname]["EngineeringSystem"])))

    return jsonify({'engsystems': filtered_eng_systems})

@app.route('/filter', methods=['POST'])
def filter_data():
    turbineevent_df, log_df = fetch_turbine_data()
    
    selected_logno = request.form.get('logno', '').strip()
    selected_ctrlname = request.form.get('ctrlname', '')
    selected_engsystem = request.form.get('engsystem', '')
    filtered_turbineevent_df = turbineevent_df
    filtered_log_df = log_df
    # Apply filters only if values are provided
    if selected_logno:
        filtered_turbineevent_df = filtered_turbineevent_df[filtered_turbineevent_df["Logno"].astype(str) == selected_logno]
        filtered_log_df = filtered_log_df[filtered_log_df["LogNo"].astype(str) == selected_logno]

    if selected_ctrlname:
        filtered_turbineevent_df = filtered_turbineevent_df[filtered_turbineevent_df["ControllerName"] == selected_ctrlname]
        filtered_log_df = filtered_log_df[filtered_log_df["Controllername"] == selected_ctrlname]

    if selected_engsystem:
        filtered_turbineevent_df = filtered_turbineevent_df[filtered_turbineevent_df["EngineeringSystem"] == selected_engsystem]
        filtered_log_df = filtered_log_df[filtered_log_df["EngineeringSystem"] == selected_engsystem]
    table1_columns = list(filtered_turbineevent_df.columns)
    table2_columns = list(filtered_log_df.columns)
    return render_template('home_new.html', 
                       ctrlnames=sorted(set(turbineevent_df["ControllerName"]).union(set(log_df["Controllername"]))),
                       selected_ctrlname=selected_ctrlname, 
                       selected_engsystem=selected_engsystem,
                       table2_columns = table2_columns,
                       table1_columns = table1_columns,
                       table1_data=filtered_turbineevent_df.to_dict(orient='records'),
                       table2_data=filtered_log_df.to_dict(orient='records'),user=session['user_name'], type=session['type'])  

@app.route('/admin')
def admin():
    try:

        cnxn = pyodbc.connect(cnxn_str)
        cursor = cnxn.cursor()

        cursor.execute("SELECT * FROM rocc.staging_table")
        rows = cursor.fetchall()

        columns = [desc[0] for desc in cursor.description]

        staging_data = [dict(zip(columns, row)) for row in rows]

        cursor.close()
        cnxn.close()

        return render_template('admin_new.html', staging_columns=columns, staging_data=staging_data)

    except Exception as e:
        print(e)
        return jsonify({"error": str(e)}), 500



from flask import request, jsonify, session
from datetime import datetime
import pyodbc

@app.route('/add_entry', methods=['POST'])
def add_entry():
    try:
        data = request.get_json()

        # Check if all required fields are filled
        if not all(data.values()):
            return jsonify({"error": "All fields are required"}), 400

        # Add the current user and timestamp
        data['Added by'] = session.get('user_name', 'unknown')
        data['Added On'] = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')  # store as UTC in SQL DATETIME

        # Prepare columns and values
        columns = list(data.keys())
        values = list(data.values())
     
        mail_df = pd.DataFrame([values], columns=columns)

        # Wrap column names in double quotes (for special characters)
        quoted_columns = ', '.join([f'"{col}"' for col in columns])
        placeholders = ', '.join(['?'] * len(values))

        # Prepare SQL query
        query = f"INSERT INTO rocc.staging_table ({quoted_columns}) VALUES ({placeholders})"

        # Debug print
        print("Query:", query)
        print("Values:", values)

        # Connect to SQL Server
        cnxn = pyodbc.connect(cnxn_str)
        cursor = cnxn.cursor()

        # Execute query
        cursor.execute(query, values)
        cnxn.commit()

        # Clean up
        cursor.close()
        cnxn.close()
        send_email('sakst@vestas.com', 'New Entry In Staging Table' ,"Hi Admin,\n \n Please be aware that some modifications have been made in the Staging Table.\n",mail_df)
        return jsonify({"message": "Entry added successfully!"}), 200

    except Exception as e:
        print(f"Error: {str(e)}")
        try:
            if cnxn:
                cnxn.rollback()
                cnxn.close()
        except:
            pass
        return jsonify({"error": str(e)}), 500


# @app.route('/add_entry', methods=['POST'])
# def add_entry():
#     data = request.get_json()

#     db, local_cursor = get_db()

#     # Ensure all fields are provided
#     if not all(data.values()):
#         return jsonify({"error": "All fields are required"}), 400
#     data['Added by'] = session.get('user_name', 'unknown')
#     # Convert dictionary into SQL query
#     columns = ', '.join(data.keys())
#     values = ', '.join([f"'{value}'" for value in data.values()])
#     print(columns)
#     print(values)
#     query = f"INSERT INTO staging_table ({columns}) VALUES ({values})"
#     connection = pyodbc.connect(cnxn_str)
#     cursor = connection.cursor()
    

#     try:
#         columns = ', '.join([f'"{key}"' for key in data.keys()])
#         placeholders = ', '.join(['%s'] * len(data))  # Secure placeholders
#         values = tuple(data.values())

#         query = f"INSERT INTO staging_table ({columns}) VALUES ({placeholders})"
#         local_cursor.execute(query, values)
#         db.commit()

#         return jsonify({"message": "Entry added successfully!"}), 200
#     except Exception as e:
#         print(e)
#         db.rollback()
#         return jsonify({"error": str(e)}), 500


@app.route('/approve', methods=['POST'])
def approve_data():
    try:
        data = request.get_json()

        if not data or "selected_rows" not in data:
            return jsonify({"message": "No valid data received"}), 400

        print("\nReceived JSON Data:", data)

        for row in data["selected_rows"]:
            log_no = row.get('LogNo')
            controller_name = row.get('Controllername')
            description = row.get('Description')
            d_turbine_event_id = row.get('DTurbineeventid')
            engineering_system = row.get('EngineeringSystem')
            competing_rank = row.get('CompetingforRankinTEIDSoln')
            remarks = row.get('Remarks (Why were they added in the table ?)')
            added_by = row.get('Added by')
            added_on = row.get('Added On')
            row_id = row.get('id')

            if log_no and controller_name:
                # Check if LogNo exists
                check_query = """
                    SELECT COUNT(*) FROM rocc.LogNoSystemClassification 
                    WHERE "LogNo" = ? AND "Controllername" = ?
                """
                try:
                    connection = pyodbc.connect(cnxn_str)
                    cursor = connection.cursor()
                    
                    cursor.execute(check_query, (log_no, controller_name))
                    exists = cursor.fetchone()[0]

                    if exists:
                        print("If block")
                        print(log_no, controller_name, description, d_turbine_event_id, 
                              engineering_system, competing_rank, remarks, 
                              added_by, added_on)
                        # Update existing entry
                        update_query = """
                            UPDATE rocc.LogNoSystemClassification 
                            SET "EngineeringSystem" = ? 
                            WHERE "LogNo" = ? AND "Controllername" = ?
                        """
                        cursor.execute(update_query, (engineering_system, log_no, controller_name))
                    else:
                        print("Else block")
                        print(log_no, controller_name, description, d_turbine_event_id, 
                              engineering_system, competing_rank, remarks, 
                              added_by, added_on)
                        if added_on:
                            added_on = datetime.strptime(added_on, '%Y-%m-%d %H:%M:%S')
                        else:
                            added_on = None
                        print(log_no, controller_name, description, d_turbine_event_id, 
                              engineering_system, competing_rank, remarks, 
                              added_by, added_on)

                        # Insert new entry
                        insert_query = """
                            INSERT INTO rocc.LogNoSystemClassification VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """
                        cursor.execute(insert_query, (log_no, controller_name, description, d_turbine_event_id, 
                                                      engineering_system, competing_rank, remarks, 
                                                      added_by, added_on))
                        print("New Insert>>>>>>>>")
                    connection.commit()
                    print("New insert completed!!!!!!!!!!!!!!!!!")
                except pyodbc.Error as e:
                    print(f"Database error: {e}")
                
                finally:
                    cursor.close()
                    connection.close()

            # Delete from rocc.staging_table if row_id exists
            if row_id:
                delete_query = """
                    DELETE FROM rocc.staging_table 
                    WHERE "id" = ?
                """
                try:
                    connection = pyodbc.connect(cnxn_str)
                    cursor = connection.cursor()
                    cursor.execute(delete_query, (row_id,))
                    connection.commit()
                    print(f"Deleted row with id: {row_id} from rocc.staging_table")
                except pyodbc.Error as e:
                    print(f"Database error during delete: {e}")
                finally:
                    cursor.close()
                    connection.close()

        # Return success message after processing all rows
        return jsonify({"message": "EngineeringSystem updated successfully"}), 200

    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({"error": "An error occurred while updating the database"}), 500



@app.route('/disapprove', methods=['POST'])
def disapprove_data():
    try:
        print("Deletion>>>>")
        data = request.get_json()
        print("Received Data:", data)

        for row in data.get("selected_rows", []):  # Ensure selected_rows exists
            row_id = row.get('id')
            print(f"Deleting ID: {row_id}")  # Debug print

            if row_id is None:
                print("Skipping deletion as row_id is None")
                continue  # Skip if ID is not present

            # Construct the DELETE query for rocc.staging_table
            delete_query = """
                DELETE FROM rocc.staging_table 
                WHERE "id" = ?
            """

            try:
                # Establish pyodbc connection to the database
                connection = pyodbc.connect(cnxn_str)
                cursor = connection.cursor()

                # Execute the delete query
                cursor.execute(delete_query, (row_id,))
                connection.commit()

                print(f"Deleted row with id: {row_id} from rocc.staging_table")
                
            except pyodbc.Error as e:
                print(f"Database error during delete: {e}")
            
            finally:
                cursor.close()
                connection.close()

        print("Deletion completed successfully.")
        return jsonify({"message": "Entry deleted"}), 200

    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({"error": "An error occurred while deleting the entry"}), 500

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    if request.method == 'GET':
        session.pop('user', None)
    return render_template("login.html")

if __name__=='__main__':
    app.run(host='0.0.0.0',port=5000,debug=True)
