import hashlib
import pyodbc

# Function to hash password (mimicking SQL Server's SHA2_256 + hex)
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest().upper()

# Connection string to your SQL Server
cnxn_str = ("Driver={ODBC Driver 17 for SQL Server};"
            "Server=dkrdsvdcp11\dpa;"
            "Database=VPDC;"
            "Trusted_Connection=yes;")

def authenticate(username, password):
    hashed_pw = hash_password(password)

    try:
        with pyodbc.connect(cnxn_str) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, type FROM rocc.users 
                WHERE username = ? AND password = ?
            """, (username, hashed_pw))
            user = cursor.fetchone()

            if user:
                print(f"\n✅ Login successful!\nUser ID: {user.id}\nUser Type: {user.type}")
            else:
                print("\n❌ Invalid username or password.")
    except Exception as e:
        print(f"\n⚠️ Error: {e}")

if __name__ == "__main__":
    print("=== User Login ===")
    username = input("Username: ").strip()
    password = input("Password: ").strip()
    
    authenticate(username, password)
